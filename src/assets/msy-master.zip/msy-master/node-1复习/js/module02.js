var module=require("./module01.js");
console.log(module.abc);
module.hi();