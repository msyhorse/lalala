console.log("hello world");
console.log("啦啦啦啦啦");