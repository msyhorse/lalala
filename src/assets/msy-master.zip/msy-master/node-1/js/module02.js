var module = require("./module01.js");
console.log(module.abc);
// console.log(module.hi());
module.hi();