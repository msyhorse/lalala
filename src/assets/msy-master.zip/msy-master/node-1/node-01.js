console.log("hello world");
console.log("疫情快点结束，我想上班！");