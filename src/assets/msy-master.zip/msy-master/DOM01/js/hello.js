(function(){
	function sayhello(){
		console.log("hello world");
	}
	window.sayhello=sayhello;
}())
