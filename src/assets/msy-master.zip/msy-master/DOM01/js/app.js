(function(){
	sayhello();
}())
