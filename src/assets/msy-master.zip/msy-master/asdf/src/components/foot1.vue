<template>
  <div>
<div class="a1">
<div class="a2">
  <img src="../assets/logo_new.png" alt="123123" width="120" class="a3">
  <div class="a5">
  <p class="a4">重点城市程序员兼职推荐</p>
   <div class="a6">
<a href="#" class="a7">北京程序员兼职</a>
<a href="#" class="a7">上海程序员兼职</a>
<a href="#" class="a7">深圳程序员兼职</a>
<a href="#" class="a7">杭州程序员兼职</a>
<a href="#" class="a7">广州程序员兼职</a>
<a href="#" class="a7">成都程序员兼职</a>
<a href="#" class="a7">武汉程序员兼职</a>
<a href="#" class="a7">南京程序员兼职</a>
<a href="#" class="a8">更多</a>
   </div>
  <p class="a4"> 重点岗位程序员兼职推荐</p>
  <div class="a6">
    <a href="#" class="a7">Java兼职</a>
<a href="#" class="a7">C++兼职</a>
<a href="#" class="a7">PHP兼职</a>
<a href="#" class="a7">C兼职</a>
<a href="#" class="a7">C#兼职</a>
<a href="#" class="a7">Python兼职</a>
<a href="#" class="a7">Ruby兼职</a>
<a href="#" class="a7">Node.js兼职</a>
<a href="#" class="a7">Android兼职</a>
<a href="#" class="a7">iOS兼职</a>
<a href="#" class="a8">更多</a>

  </div>
 
  </div>
  <div class="a10"><hr width="100%" class="a9"></div>
   <div class="a11">
     <a href="#" class="a7 a12">APP下载</a>
<a href="#" class="a7 a12">帮助</a>
<a href="#" class="a7 a12">关于我们</a>
<a href="#" class="a7 a12">合作伙伴</a>
<a href="#" class="a7 a12" id="aaa">意见反馈</a>
<a href="#" class="a7 a13">© 程序员客栈</a>
<a href="#" class="a8">浙ICP备15029175号</a><br>
<a href="#" class="a8">浙公网安备 33011002011566号</a><img class="a8" src="../assets/badge.png" alt="">

   </div>
</div>

</div>

  </div>
</template>
<script>
export default {
  
}
// alert(123)
methods:{

}
</script>
<style>
*{
  padding:0;
  margin:0;
}

.a1{
  width:100%;
  height:225px;
  /*border:1px background black;
  */
  background:white;
  /*text-align: center;*/
  overflow:hidden;
}
.a2{
  width:1044px;
  height:220px;
  border: 1px white solid;
  margin:10px auto;
}
.a3{
  float: left;
  margin-left:10px;
}
.a4{
  font-size:10px;
  width:200px;
 margin-bottom:10px;
  font-weight: bold;
}
.a5{
  width:872px;
  height:97px;
  /*border:1px black solid;*/
   float:left;
   margin-left:40px;
}
.a6{
  width:100%;
  /*border:1px black solid;*/
  height:40px;
  overflow: hidden;
}
.a7{
  font-size:10px;
  color:black;
  text-decoration:none;
  margin-right:10px;
}
.a8{
  font-size:10px;
  color:black;
  text-decoration:none;
  float:right;
}

.a10{
  width:100%;
  height:20px;
  /*background:red;*/
  margin-top:150px;
}
.a11{
  width:100%;
  height:50px;
  /*border:1px solid black;*/
  
}
.a12{
   margin-right:30px;
}
.a13{
   margin-right:30px;
   color:gray;
}
</style>


