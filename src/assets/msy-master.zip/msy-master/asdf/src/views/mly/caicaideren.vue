<template>
    <div class="e1">
        <div class="e2">码士排行榜</div>
        <div class="e3"></div>
        <div class="e4">
<ul class="e5">
    <li class="e6"><img src="../.././assets/mly/img/1.png" alt="" class="e7">
    <div class="e8"></div>
    <div class="e9"><p>123123123132123123123123132</p></div>
    
    </li>
    <li class="e6"><img src="../.././assets/mly/img/2.png" alt="" class="e7">
    <div class="e8"></div>
    <div class="e9"><p>123123123132123123123123132</p></div></li>
    <li class="e6"><img src="../.././assets/mly/img/3.png" alt="" class="e7">
    <div class="e8"></div>
    <div class="e9"><p>123123123132123123123123132</p></div></li>
    <li class="e6"><img src="../.././assets/mly/img/4.png" alt="" class="e7">
    <div class="e8"></div>
    <div class="e9"><p>123123123132123123123123132</p></div></li>
    <li class="e6"><img src="../.././assets/mly/img/5.png" alt="" class="e7">
    <div class="e8"></div>
    <div class="e9"><p>123123123132123123123123132</p></div></li>
    <li class="e6"><img src="../.././assets/mly/img/6.png" alt="" class="e7">
    <div class="e8"></div>
    <div class="e9"><p>123123123132123123123123132</p></div></li>
    <li class="e6"><img src="../.././assets/mly/img/7.png" alt="" class="e7">
    <div class="e8"></div>
    <div class="e9"><p>123123123132123123123123132</p></div></li>
    <li class="e6"><img src="../.././assets/mly/img/8.png" alt="" class="e7">
    <div class="e8"></div>
    <div class="e9"><p>123123123132123123123123132</p></div></li>
    </ul>

        </div>
         </div>
</template>
<script>

export default {
    
}
</script>
<style scoped>
.e1{
    width:100%;
    height:734px;
    /* border:1px solid black; */
    background:#F1F2F5;
    overflow: hidden;
}
.e2{
    height:53px;
    /* background:violet; */
    margin-top:47px;
    font-size:26px;
    text-align: center;
    line-height: 53px;
}.e3{
    height:36px;
    /* background:red; */
    text-align: center;
}
.e4{
    width:1243px;
    height:640px;
    /* border:1px solid black; */
    margin:auto;
}
.e5{
    width:1216px;
    height:638px;
    /* border:1px solid black; */
    margin:auto;
    list-style:none;
    float: right;
    overflow: hidden;
}
.e6{
    width:579px;
    height:109px;
    /* border:1px solid black; */
    margin-bottom: 12px;
    margin-right:27px;
    float: left;
    border-radius: 7px;
    background:white;
}
.e7{
    width:26px;
    margin-left:30px;
    margin-right:16px;
    display:inline-block;
    margin-top:27px;
    vertical-align:middle;
}
.e8{
    width:65px;
    height:65px;
    background-image: url(../.././assets/mly/img/QQ图片20200512231344.jpg);
    background-size: 101%;
    border-radius: 50px;
     /* margin-left:30px; */
    margin-right:16px;
    display:inline-block;
    margin-top:23px;
    vertical-align:middle;
}
.e9{
    width:400px;
    height:65px;
    margin-top:10px;
    /* border:1px solid black; */
    display:inline-block;
    vertical-align:bottom;
}
</style>