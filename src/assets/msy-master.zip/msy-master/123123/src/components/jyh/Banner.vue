<template>
  <div class="banner">
    <img src="../.././assets/jyh/img/top-banner-5.jpg" />
  </div>
</template>

<script>
export default {
  name: "Banner",
  data() {
    return {};
  },
  methods: {}
};
</script>
<style>
.banner img {
  width: 100%;
  min-width: 960px;
}
</style>
