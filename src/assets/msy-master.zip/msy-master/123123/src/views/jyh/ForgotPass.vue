<template>
  <div class="box">
    <h4>忘记密码</h4>
    <p>您想通过以下哪种方式重置密码</p>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
