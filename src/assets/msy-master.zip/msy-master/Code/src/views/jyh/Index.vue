<template>
  <div>
    <CaseList></CaseList>
  </div>
</template>

<script>
import CaseList from "../../components/jyh/CaseList";
export default {
  name: "Index",
  components: {
    CaseList
  },
  data() {
    return {};
  }
};
</script>

<style>
</style>