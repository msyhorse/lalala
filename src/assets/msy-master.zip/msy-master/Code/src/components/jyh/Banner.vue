<template>
  <div class="banner">
    <img src="../.././assets/jyh/img/top-banner-5.jpg" />
  </div>
</template>

<script>
export default {
  name: "Banner",
  data() {
    return {};
  },
  methods: {}
};
</script>

<style scope>
.banner img {
  border: none;
  display: inline-block;
  width: 100vw;
  min-width: 960px;
}
</style>